package com.gemwallet.android.di

import android.content.Context
import com.gemwallet.android.application.PasswordStore
import com.gemwallet.android.application.WalletPasswordProtection
import com.gemwallet.android.data.password.TinkPasswordStore
import com.gemwallet.android.data.password.WalletPasswordProtectionService
import com.gemwallet.android.data.services.gemstone.keystore.GemMigrateKeystoreOperator
import com.gemwallet.android.data.services.gemstone.keystore.MigrateKeystoreOperator
import com.gemwallet.android.ui.models.ToastPresenter
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object InteractsModule {

    @Singleton
    @Provides
    fun provideMigrateKeystoreOperator(@ApplicationContext context: Context): MigrateKeystoreOperator = GemMigrateKeystoreOperator(context.dataDir.toString())

    @Provides
    @Singleton
    fun provideTinkPasswordStore(@ApplicationContext context: Context): TinkPasswordStore = TinkPasswordStore(context)

    @Provides
    fun providePasswordStore(store: TinkPasswordStore): PasswordStore = store

    @Provides
    fun providePasswordProtection(service: WalletPasswordProtectionService): WalletPasswordProtection = service

    @Provides
    @Singleton
    fun provideToastPresenter(): ToastPresenter = ToastPresenter()
}
