package com.gemwallet.android

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gemwallet.android.application.IoDispatcher
import com.gemwallet.android.application.WalletPasswordProtection
import com.gemwallet.android.application.security.cases.SecurityPreferences
import com.gemwallet.android.application.wallet_connect.cases.IsWalletConnectEnabled
import com.gemwallet.android.application.wallet_connect.cases.PairWalletConnect
import com.gemwallet.android.data.services.gemstone.config.UserConfig
import com.gemwallet.android.ext.errorText
import com.gemwallet.android.services.MigrateV3KeystoreService
import com.gemwallet.android.ui.R
import com.gemwallet.android.ui.localization.text
import com.gemwallet.android.ui.models.ToastMessage
import com.gemwallet.android.ui.models.ToastPresenter
import com.wallet.core.primitives.Appearance
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uniffi.gemstone.GemAppStartFailure
import uniffi.gemstone.GemAppStartServiceInterface
import uniffi.gemstone.GemWalletService
import uniffi.gemstone.GemWalletServiceInterface
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val userConfig: UserConfig,
    private val securityPreferences: SecurityPreferences,
    private val passwordProtection: WalletPasswordProtection,
    private val isWalletConnectEnabledCase: IsWalletConnectEnabled,
    private val pairWalletConnect: PairWalletConnect,
    private val appStartService: GemAppStartServiceInterface,
    private val migrateV3KeystoreService: MigrateV3KeystoreService,
    private val walletService: GemWalletServiceInterface,
    private val pendingNavigationCoordinator: PendingNavigationCoordinator,
    private val toastPresenter: ToastPresenter,
    @param:IoDispatcher private val ioDispatcher: CoroutineDispatcher,
    @param:ApplicationContext private val context: Context,
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUIState())
    val uiState: StateFlow<MainUIState> = _uiState.asStateFlow()

    internal val pendingNavigation: StateFlow<PendingNavigation?> = pendingNavigationCoordinator.pendingNavigation

    val toastEvents: Flow<ToastMessage> = toastPresenter.toastEvents

    val isWalletConnectEnabled: Boolean = isWalletConnectEnabledCase.isWalletConnectEnabled()

    val appearance = userConfig.appearance()
        .stateIn(viewModelScope, SharingStarted.Eagerly, Appearance.System)

    private val walletConnectHandler = object : PendingNavigationCoordinator.WalletConnectHandler {
        override fun onPairing(uri: String) = addPairing(uri)
        override fun onRequest() {
            if (isWalletConnectEnabled) {
                showWalletConnectPairingToast()
            } else {
                showWalletConnectUnsupported()
            }
        }
    }

    private var isMaintained = false

    internal fun maintain(isUnlocked: Flow<Boolean>) {
        if (isMaintained) return
        isMaintained = true
        viewModelScope.launch {
            combine(
                isUnlocked.distinctUntilChanged(),
                pendingNavigation,
            ) { unlocked, pending -> unlocked && pending is PendingNavigation.Input }
                .distinctUntilChanged()
                .filter { it }
                .collect {
                    try {
                        pendingNavigationCoordinator.buildRoutes(walletConnectHandler)?.let { text -> showError(text.text(context)) }
                    } catch (error: CancellationException) {
                        throw error
                    } catch (error: Exception) {
                        onNavigationFailed(error)
                    }
                }
        }
        viewModelScope.launch {
            combine(
                isUnlocked.distinctUntilChanged(),
                pendingNavigation,
            ) { unlocked, pending -> unlocked && pending is PendingNavigation.Loading }
                .distinctUntilChanged()
                .filter { it }
                .collect { toastPresenter.emitToast(ToastMessage(context.getString(R.string.common_loading), R.drawable.ic_refresh)) }
        }
        viewModelScope.launch(ioDispatcher) { appStartService.run().forEach(::logAppStartFailure) }
        viewModelScope.launch(ioDispatcher) {
            isUnlocked.first { it }
            if (securityPreferences.authRequired() && !passwordProtection.authenticationRequired()) {
                runCatching { passwordProtection.setAuthenticationRequired(true) }
                    .onFailure { error ->
                        Log.e("MainViewModel", "wallet password protection failed", error)
                        _uiState.update { it.copy(startupError = error.errorText().text(context)) }
                    }
            }
            migrateV3KeystoreService()
            runCatching { walletService.migrateToSharedPassword() }
                .onFailure { error ->
                    Log.e("MainViewModel", "shared keystore password migration failed", error)
                    _uiState.update { it.copy(startupError = error.errorText().text(context)) }
                }
            appStartService.setupWallets().forEach(::logAppStartFailure)
        }
    }

    private fun logAppStartFailure(failure: GemAppStartFailure) {
        Log.e("MainViewModel", "${failure.step} failed: ${failure.message}")
    }

    fun pendIntent(intent: Intent) = pendingNavigationCoordinator.pendIntent(intent)

    fun consumePendingNavigation() = pendingNavigationCoordinator.clear()

    private fun onNavigationFailed(error: Exception) {
        val input = when (val pending = pendingNavigationCoordinator.pendingNavigation.value) {
            is PendingNavigation.Loading -> pending.input
            else -> pending as? PendingNavigation.Input
        }
        pendingNavigationCoordinator.clear()
        when (input) {
            null, is PendingNavigation.FromNotification -> Log.e("MainViewModel", "notification navigation failed", error)
            else -> showError(error.errorText().text(context))
        }
    }

    fun resetError() {
        _uiState.update {
            it.copy(
                walletConnectError = null,
                startupError = null,
                isWalletConnectUnsupportedVisible = false,
            )
        }
    }

    fun showWalletConnectError(error: String) {
        _uiState.update { it.copy(walletConnectError = error) }
    }

    private fun addPairing(uri: String) {
        if (!isWalletConnectEnabled) {
            showWalletConnectUnsupported()
            return
        }
        showWalletConnectPairingToast()
        viewModelScope.launch(ioDispatcher) {
            pairWalletConnect.pair(
                uri = uri,
                onSuccess = {},
                onError = { showWalletConnectError(it.text(context)) },
            )
        }
    }

    private fun showWalletConnectPairingToast() {
        toastPresenter.emitToast(ToastMessage("${context.getString(R.string.wallet_connect_brand_name)}...", R.drawable.ic_refresh))
    }

    private fun showError(text: String) {
        toastPresenter.emitToast(ToastMessage(text, R.drawable.ic_error))
    }

    private fun showWalletConnectUnsupported() {
        _uiState.update { it.copy(isWalletConnectUnsupportedVisible = true) }
    }

    data class MainUIState(val walletConnectError: String? = null, val startupError: String? = null, val isWalletConnectUnsupportedVisible: Boolean = false)
}
