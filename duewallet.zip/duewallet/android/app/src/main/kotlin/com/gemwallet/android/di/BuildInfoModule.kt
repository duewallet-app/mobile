package com.gemwallet.android.di

import android.content.Context
import com.gemwallet.android.application.device.cases.RequestPushToken
import com.gemwallet.android.application.notifications.cases.ShowSystemNotification
import com.gemwallet.android.flavors.StoreRequestPushToken
import com.gemwallet.android.flavors.isNotificationsAvailable
import com.gemwallet.android.model.BuildInfo
import com.gemwallet.android.model.NotificationsAvailable
import com.gemwallet.android.services.ShowSystemNotificationImpl
import com.wallet.core.primitives.PlatformStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object BuildInfoModule {

    @Provides
    @Singleton
    fun provideBuildInfo(platformStore: PlatformStore): BuildInfo = BuildInfo(
        platformStore = platformStore,
        versionName = com.gemwallet.android.BuildConfig.VERSION_NAME,
        versionCode = com.gemwallet.android.BuildConfig.VERSION_CODE,
    )

    @Provides
    @Singleton
    fun provideRequestPushToken(): RequestPushToken = StoreRequestPushToken()

    @Provides
    @Singleton
    fun provideShowSystemNotification(@ApplicationContext context: Context): ShowSystemNotification = ShowSystemNotificationImpl(context)

    @Provides
    @Singleton
    fun provideNotificationEnabled(): NotificationsAvailable = isNotificationsAvailable()

    @Provides
    @Singleton
    fun providePlatformStore(): PlatformStore {
        if (com.gemwallet.android.BuildConfig.DEBUG) {
            return PlatformStore.Local
        }
        return when (com.gemwallet.android.BuildConfig.FLAVOR) {
            "google" -> PlatformStore.GooglePlay
            "universal" -> PlatformStore.ApkUniversal
            "huawei" -> PlatformStore.Huawei
            "solana" -> PlatformStore.SolanaStore
            "fdroid" -> PlatformStore.Fdroid
            "samsung" -> PlatformStore.SamsungStore
            "emerald" -> PlatformStore.Emerald
            else -> PlatformStore.Local
        }
    }
}
