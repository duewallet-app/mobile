package com.gemwallet.android.ui.navigation

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import com.gemwallet.android.domains.swap.SwapItemType
import com.gemwallet.android.domains.wallet.WalletSecretInput
import com.gemwallet.android.ext.errorText
import com.gemwallet.android.ext.toGem
import com.gemwallet.android.ext.toIdentifier
import com.gemwallet.android.features.onboarding.presents.authentication.EnableAuthenticationRoute
import com.gemwallet.android.features.onboarding.presents.create_wallet.CreateWalletRoute
import com.gemwallet.android.features.onboarding.presents.create_wallet.CreateWalletSecurityReminderRoute
import com.gemwallet.android.features.onboarding.presents.import_wallet.ImportWalletRoute
import com.gemwallet.android.features.onboarding.presents.import_wallet.ImportWalletTypeRoute
import com.gemwallet.android.features.onboarding.presents.terms.AcceptTermsDestination
import com.gemwallet.android.features.onboarding.presents.terms.AcceptTermsRoute
import com.gemwallet.android.features.transfer.viewmodels.confirm.models.GetAssetAction
import com.gemwallet.android.model.ImportType
import com.gemwallet.android.model.Session
import com.gemwallet.android.testkit.mockAsset
import com.gemwallet.android.testkit.mockAssetId
import com.gemwallet.android.testkit.mockSession
import com.gemwallet.android.testkit.mockTransactionId
import com.gemwallet.android.testkit.mockWallet
import com.gemwallet.android.ui.models.navigation.RouteMessage
import com.gemwallet.android.ui.navigation.routes.AmountRoute
import com.gemwallet.android.ui.navigation.routes.AssetPriceAlertsRoute
import com.gemwallet.android.ui.navigation.routes.AssetRoute
import com.gemwallet.android.ui.navigation.routes.ChartRoute
import com.gemwallet.android.ui.navigation.routes.ConfirmTransferRoute
import com.gemwallet.android.ui.navigation.routes.DelegationRoute
import com.gemwallet.android.ui.navigation.routes.ExportWalletRoute
import com.gemwallet.android.ui.navigation.routes.PerpetualDepositSelectRoute
import com.gemwallet.android.ui.navigation.routes.PerpetualsRoute
import com.gemwallet.android.ui.navigation.routes.ReceiveRoute
import com.gemwallet.android.ui.navigation.routes.RecipientRoute
import com.gemwallet.android.ui.navigation.routes.RewardsRoute
import com.gemwallet.android.ui.navigation.routes.SecurityReminderRoute
import com.gemwallet.android.ui.navigation.routes.SetPriceAlertRoute
import com.gemwallet.android.ui.navigation.routes.SettingsRoute
import com.gemwallet.android.ui.navigation.routes.StakeRoute
import com.gemwallet.android.ui.navigation.routes.SupportRoute
import com.gemwallet.android.ui.navigation.routes.SwapPairRoute
import com.gemwallet.android.ui.navigation.routes.SwapRoute
import com.gemwallet.android.ui.navigation.routes.SwapSelectRoute
import com.gemwallet.android.ui.navigation.routes.TransactionRoute
import com.gemwallet.android.ui.navigation.routes.WalletConnectorRequestRoute
import com.gemwallet.android.ui.navigation.routes.WalletDetailRoute
import com.gemwallet.android.ui.navigation.routes.WalletRoute
import com.gemwallet.android.ui.navigation.routes.WalletsRoute
import com.wallet.core.primitives.Chain
import com.wallet.core.primitives.WalletId
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.job
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import uniffi.gemstone.GemDeeplinkService
import uniffi.gemstone.GemNavigationServiceInterface
import uniffi.gemstone.GemNavigationTab
import uniffi.gemstone.GemNavigationTarget
import uniffi.gemstone.GemServiceException
import uniffi.gemstone.GemWalletImportKind
import uniffi.gemstone.GemWalletSecretKind
import uniffi.gemstone.UrlAction
import uniffi.gemstone.WalletConnectLink

@OptIn(ExperimentalCoroutinesApi::class)
class WalletNavigatorTest {
    @Before
    fun setUp() {
        mockkStatic(Log::class)
        every { Log.e(any(), any(), any()) } returns 0
    }

    @After
    fun tearDown() {
        unmockkStatic(Log::class)
    }

    @Test
    fun openNotificationUrl_reportsTheFailureToTheScreenTheLinkWasTappedOn() = runTest {
        val error = GemServiceException.NotFound("asset not found")
        val navigationService = mockk<GemNavigationServiceInterface> {
            coEvery { openDeeplink(any()) } throws error
        }
        val navigator = navigatorWith(WalletRootRoute, SupportRoute, navigationService = navigationService, scope = this)

        val handled = navigator.openNotificationUrl("https://gemwallet.com/tokens/ethereum/0x1111111111111111111111111111111111111111/buy")
        coroutineContext.job.children.toList().joinAll()

        assertTrue(handled)
        assertEquals(listOf(WalletRootRoute, SupportRoute), navigator.backStack.toList())
        assertEquals(RouteMessage.Error(error.errorText()), navigator.routeMessage(SupportRoute))
        assertNull(navigator.routeMessage(WalletRootRoute))

        navigator.clearRouteMessage(SupportRoute)

        assertNull(navigator.routeMessage(SupportRoute))
    }

    @Test
    fun openUrlAction_handsPaymentAndWalletConnectActionsToThePendingNavigation() {
        val opened = mutableListOf<UrlAction>()
        val navigator = navigatorWith(WalletRootRoute, SupportRoute, onOpenAction = { opened.add(it) })
        val walletConnect = UrlAction.WalletConnect(WalletConnectLink.Request)

        assertTrue(navigator.openUrlAction(walletConnect))

        assertEquals(listOf<UrlAction>(walletConnect), opened)
        assertEquals(listOf(WalletRootRoute, SupportRoute), navigator.backStack.toList())
    }

    @Test
    fun openAsset_leavesTheStackAloneWhenCoreFailsToOpenIt() = runTest {
        val assetId = mockAssetId(Chain.Tron)
        val navigationService = mockk<GemNavigationServiceInterface> {
            coEvery { openAsset(assetId.toIdentifier()) } throws GemServiceException.Api("offline")
        }
        val navigator = navigatorWith(WalletRootRoute, navigationService = navigationService, scope = this)

        navigator.openAsset(assetId).join()

        assertEquals(listOf(WalletRootRoute), navigator.backStack.toList())
    }

    @Test
    fun openAsset_pushesOnlyAssetsCoreOpens() = runTest {
        val blocked = mockAssetId(Chain.Tempo)
        val opened = mockAssetId(Chain.Tron)
        val callingThreads = mutableListOf<String>()
        val navigationService = mockk<GemNavigationServiceInterface> {
            coEvery { openAsset(blocked.toIdentifier()) } answers {
                callingThreads += Thread.currentThread().name
                GemNavigationTarget.None
            }
            coEvery { openAsset(opened.toIdentifier()) } answers {
                callingThreads += Thread.currentThread().name
                GemNavigationTarget.Asset(mockAsset(id = mockAssetId(chain = Chain.Tron)).toGem(), walletId = null, isPerpetual = false)
            }
        }
        val navigator = navigatorWith(WalletRootRoute, navigationService = navigationService, scope = this)

        navigator.openAsset(blocked).join()
        navigator.openAsset(opened).join()

        assertEquals(listOf(WalletRootRoute, AssetRoute(opened)), navigator.backStack.toList())
        assertTrue(
            "openAsset reads the current wallet through a synchronous store callback that blocks on Room; " +
                "calling it on the navigator scope lands on main. Got $callingThreads",
            callingThreads.size == 2 && callingThreads.all { it.startsWith("DefaultDispatcher-worker") },
        )
    }

    @Test
    fun finishAcceptTerms_replacesCreateTermsRoute() {
        val navigator = navigatorWith(OnboardingRoute, AcceptTermsRoute(AcceptTermsDestination.Create))

        navigator.finishAcceptTerms(AcceptTermsDestination.Create)

        assertEquals(listOf(OnboardingRoute, CreateWalletSecurityReminderRoute), navigator.backStack.toList())
    }

    @Test
    fun finishAcceptTerms_replacesImportTermsRoute() {
        val navigator = navigatorWith(OnboardingRoute, AcceptTermsRoute(AcceptTermsDestination.Import))

        navigator.finishAcceptTerms(AcceptTermsDestination.Import)

        assertEquals(listOf(OnboardingRoute, ImportWalletTypeRoute), navigator.backStack.toList())
    }

    @Test
    fun resetToWallet_landsOnTheWalletFromCreateOrImport() {
        val createNavigator = navigatorWith(OnboardingRoute, CreateWalletRoute)
        val importNavigator = navigatorWith(OnboardingRoute, ImportWalletRoute.MulticoinWallet)

        createNavigator.resetToWallet()
        importNavigator.resetToWallet()

        assertEquals(listOf(WalletRootRoute), createNavigator.backStack.toList())
        assertEquals(listOf(WalletRootRoute), importNavigator.backStack.toList())
    }

    @Test
    fun openEnableAuthentication_offersOverTheWalletSoARestoreKeepsTheOffer() {
        val navigator = navigatorWith(OnboardingRoute, CreateWalletRoute)

        navigator.openEnableAuthentication()

        val stack = navigator.backStack.toList()
        assertEquals(listOf(WalletRootRoute, EnableAuthenticationRoute), stack)
        assertEquals(stack, stack.dropNonRestorableRoutes(OnboardingRoute))
        assertEquals(stack, stack.dropNonRestorableRoutes(WalletRootRoute))
    }

    @Test
    fun openPendingNavigation_resetsWalletStackAndOpensRoute() {
        val navigator = navigatorWith(WalletRootRoute, WalletsRoute)
        val route = AssetRoute(mockAssetId(Chain.Solana))

        val opened = navigator.openPendingNavigation(listOf(route))

        assertTrue(opened)
        assertEquals(listOf(WalletRootRoute, route), navigator.backStack.toList())
    }

    @Test
    fun openPendingNavigation_selectsTheTabCoreNamed() {
        val navigator = navigatorWith(WalletRootRoute)

        navigator.openPendingNavigation(listOf(RewardsRoute(code = null)), GemNavigationTab.SETTINGS)

        assertEquals(SettingsRoute, navigator.currentTab.value)
    }

    @Test
    fun openPendingNavigation_waitsWhenWalletRootIsUnavailable() {
        val navigator = navigatorWith(OnboardingRoute)

        val opened = navigator.openPendingNavigation(listOf(AssetRoute(mockAssetId(Chain.Solana))))

        assertFalse(opened)
        assertEquals(listOf(OnboardingRoute), navigator.backStack.toList())
    }

    @Test
    fun openPendingNavigation_resetsActiveTransactionFlow() {
        val navigator = navigatorWith(
            WalletRootRoute,
            AssetRoute(mockAssetId(Chain.Solana)),
            AmountRoute("amount"),
        )
        val route = AssetRoute(mockAssetId(Chain.Ethereum))

        val opened = navigator.openPendingNavigation(listOf(route))

        assertTrue(opened)
        assertEquals(listOf(WalletRootRoute, route), navigator.backStack.toList())
    }

    @Test
    fun openPendingNavigation_resetsSecretPhraseFlow() {
        val walletId = WalletId("wallet-1")
        val navigator = navigatorWith(
            WalletRootRoute,
            WalletDetailRoute(walletId),
            ExportWalletRoute(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE)),
        )
        val route = AssetRoute(mockAssetId(Chain.Solana))

        val opened = navigator.openPendingNavigation(listOf(route))

        assertTrue(opened)
        assertEquals(listOf(WalletRootRoute, route), navigator.backStack.toList())
    }

    @Test
    fun finishWalletSecurityReminder_replacesReminderWithPhraseRoute() {
        val walletId = WalletId("wallet-1")
        val navigator = navigatorWith(
            WalletRootRoute,
            WalletDetailRoute(walletId),
            SecurityReminderRoute(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE)),
        )

        navigator.finishWalletSecurityReminder(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE))

        assertEquals(
            listOf(
                WalletRootRoute,
                WalletDetailRoute(walletId),
                ExportWalletRoute(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE)),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun dropNonRestorableRoutes_keepsTheLiveRootWhenItDiffersFromTheStartDestination() {
        val assetId = mockAssetId(Chain.Solana)

        val restored = listOf<NavKey>(
            WalletRootRoute,
            AssetRoute(assetId),
        ).dropNonRestorableRoutes(OnboardingRoute)

        assertEquals(listOf(WalletRootRoute, AssetRoute(assetId)), restored)
    }

    @Test
    fun dropNonRestorableRoutes_keepsOnboardingRootAgainstAWalletStartDestination() {
        val restored = listOf<NavKey>(OnboardingRoute).dropNonRestorableRoutes(WalletRootRoute)

        assertEquals(listOf(OnboardingRoute), restored)
    }

    @Test
    fun dropNonRestorableRoutes_fallsBackToStartDestinationWhenTheRootIsNotARoot() {
        val assetId = mockAssetId(Chain.Solana)

        val restored = listOf<NavKey>(
            AssetRoute(assetId),
            AmountRoute("amount"),
        ).dropNonRestorableRoutes(WalletRootRoute)

        assertEquals(listOf(WalletRootRoute), restored)
    }

    @Test
    fun dropNonRestorableRoutes_removesSensitiveAndInFlightRoutes() {
        val assetId = mockAssetId(Chain.Solana)
        val walletId = WalletId("wallet-1")

        val restored = listOf<NavKey>(
            WalletRootRoute,
            AssetRoute(assetId),
            SecurityReminderRoute(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE)),
            ExportWalletRoute(WalletSecretInput(walletId, GemWalletSecretKind.PHRASE)),
            CreateWalletRoute,
            RecipientRoute(assetId),
            AmountRoute("amount"),
            AmountRoute("perpetual"),
            ConfirmTransferRoute("confirm"),
        ).dropNonRestorableRoutes(WalletRootRoute)

        assertEquals(listOf(WalletRootRoute, AssetRoute(assetId)), restored)
    }

    @Test
    fun openImportWallet_usesValidTypedRoutes() {
        val navigator = navigatorWith(OnboardingRoute)

        navigator.openImportWallet()
        navigator.openImportWallet(ImportType(GemWalletImportKind.PHRASE))
        navigator.openImportWallet(ImportType(GemWalletImportKind.PRIVATE_KEY, Chain.Solana))

        assertEquals(
            listOf(
                OnboardingRoute,
                ImportWalletTypeRoute,
                ImportWalletRoute.MulticoinWallet,
                ImportWalletRoute.ChainWallet(GemWalletImportKind.PRIVATE_KEY, Chain.Solana),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun openGetAsset_swapWithoutPayAssetOpensWithTheMissingAssetToReceive() {
        val navigator = navigatorWith(WalletRootRoute)
        val receiveAssetId = mockAssetId(Chain.Tron)

        navigator.openGetAsset(GetAssetAction.Swap(payAssetId = null), receiveAssetId)

        assertEquals(listOf(WalletRootRoute, SwapPairRoute(from = null, to = receiveAssetId)), navigator.backStack.toList())
    }

    @Test
    fun finishSwapSelect_popsSelectorAndStoresSelectionForTargetRoute() {
        val route = SwapPairRoute(mockAssetId(Chain.Bitcoin), to = null)
        val selectedPayAssetId = mockAssetId(Chain.Solana)
        val navigator = navigatorWith(
            WalletRootRoute,
            route,
            SwapSelectRoute(SwapItemType.Pay, payAssetId = null, receiveAssetId = null),
        )

        navigator.finishSwapSelect(itemType = SwapItemType.Pay, assetId = selectedPayAssetId)

        assertEquals(listOf(WalletRootRoute, route), navigator.backStack.toList())
        assertEquals(
            SwapSelection(SwapItemType.Pay, assetId = selectedPayAssetId),
            navigator.swapSelection(route),
        )
        assertNull(navigator.swapSelection(SwapRoute))

        navigator.clearSwapSelection(route)

        assertNull(navigator.swapSelection(route))
    }

    @Test
    fun popConfirmFlow_popsTransferFlowToAsset() {
        val assetId = mockAssetId(Chain.Solana)
        val navigator = navigatorWith(
            WalletRootRoute,
            WalletsRoute,
            AssetRoute(assetId),
            RecipientRoute(assetId),
            AmountRoute("amount"),
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(
            listOf(
                WalletRootRoute,
                WalletsRoute,
                AssetRoute(assetId),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun popConfirmFlow_popsStakeFlowToLaunchingAsset() {
        val previousAssetId = mockAssetId(Chain.Ethereum)
        val stakeAssetId = mockAssetId(Chain.Solana)
        val navigator = navigatorWith(
            WalletRootRoute,
            AssetRoute(previousAssetId),
            AssetRoute(stakeAssetId),
            StakeRoute(stakeAssetId),
            AmountRoute("amount"),
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(
            listOf(
                WalletRootRoute,
                AssetRoute(previousAssetId),
                AssetRoute(stakeAssetId),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun popConfirmFlow_popsDelegationStakeFlowToLaunchingAsset() {
        val assetId = mockAssetId(Chain.Solana)
        val navigator = navigatorWith(
            WalletRootRoute,
            AssetRoute(assetId),
            StakeRoute(assetId),
            DelegationRoute(validatorId = "validator", delegationId = "delegation"),
            AmountRoute("amount"),
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(
            listOf(
                WalletRootRoute,
                AssetRoute(assetId),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun popConfirmFlow_popsSwapFlowToAsset() {
        val assetId = mockAssetId(Chain.Ethereum)
        val navigator = navigatorWith(
            WalletRootRoute,
            WalletsRoute,
            AssetRoute(assetId),
            SwapPairRoute(assetId, to = null),
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(
            listOf(
                WalletRootRoute,
                WalletsRoute,
                AssetRoute(assetId),
            ),
            navigator.backStack.toList(),
        )
    }

    @Test
    fun popConfirmFlow_popsPerpetualDepositFlowToPerpetuals() {
        val navigator = navigatorWith(
            WalletRootRoute,
            PerpetualsRoute,
            PerpetualDepositSelectRoute,
            AmountRoute("amount"),
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(listOf(WalletRootRoute, PerpetualsRoute), navigator.backStack.toList())
    }

    @Test
    fun popConfirmFlow_popsToRootWhenNoAssetUnderneath() {
        val navigator = navigatorWith(
            WalletRootRoute,
            ConfirmTransferRoute("confirm"),
        )

        navigator.popConfirmFlow()

        assertEquals(listOf(WalletRootRoute), navigator.backStack.toList())
    }

    @Test
    fun popWithToast_scopesMessageToPreviousRoute() {
        val assetId = mockAssetId(Chain.Solana)
        val target = AssetPriceAlertsRoute(assetId)
        val otherTarget = ChartRoute(assetId)
        val navigator = navigatorWith(
            WalletRootRoute,
            target,
            SetPriceAlertRoute(assetId),
        )

        navigator.popWithToast("Created")

        assertEquals(listOf(WalletRootRoute, target), navigator.backStack.toList())
        assertEquals(RouteMessage.Toast("Created"), navigator.routeMessage(target))
        assertNull(navigator.routeMessage(otherTarget))

        navigator.clearRouteMessage(target)

        assertNull(navigator.routeMessage(target))
    }

    @Test
    fun showWalletConnectorRequest_pushesOneRouteAndReplacesItForTheNextRequest() {
        val navigator = navigatorWith(WalletRootRoute)

        navigator.showWalletConnectorRequest("request/topic/1")
        navigator.showWalletConnectorRequest("request/topic/1")
        assertEquals(listOf(WalletRootRoute, WalletConnectorRequestRoute("request/topic/1")), navigator.backStack.toList())

        navigator.showWalletConnectorRequest("request/topic/2")
        assertEquals(listOf(WalletRootRoute, WalletConnectorRequestRoute("request/topic/2")), navigator.backStack.toList())
    }

    @Test
    fun showWalletConnectorRequest_removesTheRouteUnderneathAScreenItOpened() {
        val navigator = navigatorWith(WalletRootRoute, WalletConnectorRequestRoute("request/topic/1"), ReceiveRoute(mockAssetId(Chain.Tron)))

        navigator.showWalletConnectorRequest(null)

        assertEquals(listOf(WalletRootRoute, ReceiveRoute(mockAssetId(Chain.Tron))), navigator.backStack.toList())
    }

    @Test
    fun aWalletChangeUnderAWalletConnectRequestReturnsToTheWalletWithTheRequestOnTop() = runTest(UnconfinedTestDispatcher()) {
        val session = MutableStateFlow<Session?>(mockSession(wallet = mockWallet(id = WalletId("current"))))
        val request = WalletConnectorRequestRoute("request/topic/1")
        val navigator = navigatorWith(WalletRootRoute, ReceiveRoute(mockAssetId(Chain.Tron)), request, session = session)
        backgroundScope.launch { navigator.observeCurrentWallet() }

        session.value = mockSession(wallet = mockWallet(id = WalletId("requested")))

        assertEquals(listOf(WalletRootRoute, request), navigator.backStack.toList())
    }

    @Test
    fun aWalletChangeWithoutAWalletConnectRequestLeavesNavigationToTheScreenThatChangedIt() = runTest(UnconfinedTestDispatcher()) {
        val session = MutableStateFlow<Session?>(mockSession(wallet = mockWallet(id = WalletId("current"))))
        val navigator = navigatorWith(WalletRootRoute, ReceiveRoute(mockAssetId(Chain.Tron)), session = session)
        backgroundScope.launch { navigator.observeCurrentWallet() }

        session.value = mockSession(wallet = mockWallet(id = WalletId("other")))

        assertEquals(listOf(WalletRootRoute, ReceiveRoute(mockAssetId(Chain.Tron))), navigator.backStack.toList())
    }

    @Test
    fun openTransaction_keysTheDetailsToTheWalletTheyAreOpenedFor() {
        val wallet = mockWallet(id = WalletId("shown"))
        val transactionId = mockTransactionId()
        val navigator = navigatorWith(WalletRootRoute, session = MutableStateFlow(mockSession(wallet = wallet)))

        navigator.openTransaction(transactionId)

        assertEquals(listOf(WalletRootRoute, TransactionRoute(wallet.id, transactionId)), navigator.backStack.toList())
    }

    private fun navigatorWith(
        vararg routes: NavKey,
        navigationService: GemNavigationServiceInterface = mockk(relaxed = true),
        session: StateFlow<Session?> = MutableStateFlow(null),
        scope: CoroutineScope = CoroutineScope(Dispatchers.Unconfined),
        onOpenAction: (UrlAction) -> Unit = {},
    ): WalletNavigator = WalletNavigator(
        backStack = NavBackStack(*routes),
        currentTab = mutableStateOf(WalletRoute),
        deeplinkService = GemDeeplinkService(),
        navigationService = navigationService,
        session = session,
        scope = scope,
        onOpenAction = onOpenAction,
    )
}
