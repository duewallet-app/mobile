package com.gemwallet.android.data.coordinators.di

import com.gemwallet.android.application.session.cases.GetCurrentCurrency
import com.gemwallet.android.application.session.cases.GetCurrentWalletId
import com.gemwallet.android.application.session.cases.GetSession
import com.gemwallet.android.application.session.cases.SetCurrentCurrency
import com.gemwallet.android.data.coordinators.session.GetCurrentWalletIdImpl
import com.gemwallet.android.data.coordinators.session.SessionCoordinator
import com.gemwallet.android.data.services.gemstone.stores.GemstoneWalletSessionStore
import com.gemwallet.android.data.services.store.queries.WalletQuery
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import uniffi.gemstone.GemCurrencyService
import uniffi.gemstone.GemCurrencyServiceInterface
import uniffi.gemstone.GemPreferencesService
import uniffi.gemstone.GemPriceService
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object SessionModule {

    @Provides
    @Singleton
    fun provideGemCurrencyService(priceService: GemPriceService): GemCurrencyService = GemCurrencyService(priceService)

    @Provides
    fun provideGemCurrencyServiceInterface(service: GemCurrencyService): GemCurrencyServiceInterface = service

    @Provides
    @Singleton
    fun provideSessionCoordinator(sessionStore: GemstoneWalletSessionStore, walletQuery: WalletQuery, preferencesService: GemPreferencesService, currencyService: GemCurrencyService): SessionCoordinator = SessionCoordinator(
        sessionStore = sessionStore,
        walletQuery = walletQuery,
        preferencesService = preferencesService,
        currencyService = currencyService,
    )

    @Provides
    @Singleton
    fun provideGetSession(coordinator: SessionCoordinator): GetSession = coordinator

    @Provides
    @Singleton
    fun provideGetCurrentCurrency(coordinator: SessionCoordinator): GetCurrentCurrency = coordinator

    @Provides
    @Singleton
    fun provideSetCurrentCurrency(coordinator: SessionCoordinator): SetCurrentCurrency = coordinator

    @Provides
    @Singleton
    fun provideGetCurrentWalletId(getSession: GetSession): GetCurrentWalletId = GetCurrentWalletIdImpl(getSession)
}
