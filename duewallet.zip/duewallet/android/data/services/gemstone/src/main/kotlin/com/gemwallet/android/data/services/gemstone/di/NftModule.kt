package com.gemwallet.android.data.services.gemstone.di

import com.gemwallet.android.data.services.store.database.NftDao
import com.gemwallet.android.data.services.gemstone.stores.GemstoneNftStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import uniffi.gemstone.GemAvatarService
import uniffi.gemstone.GemCollectibleService
import uniffi.gemstone.GemCollectibleServiceInterface
import uniffi.gemstone.GemDeviceApiClient
import uniffi.gemstone.GemExplorerService
import uniffi.gemstone.GemNftService
import uniffi.gemstone.GemNftServiceInterface
import uniffi.gemstone.GemWalletSessionService
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class NftModule {

    @Provides
    @Singleton
    fun provideGemstoneNftStore(nftDao: NftDao): GemstoneNftStore = GemstoneNftStore(nftDao)

    @Provides
    @Singleton
    fun provideGemNftService(apiClient: GemDeviceApiClient, nftStore: GemstoneNftStore, walletSessionService: GemWalletSessionService): GemNftService = GemNftService(apiClient, nftStore, walletSessionService)

    @Provides
    fun provideGemCollectibleService(nfts: GemNftService, avatars: GemAvatarService, explorer: GemExplorerService): GemCollectibleServiceInterface = GemCollectibleService(nfts, avatars, explorer)

    @Provides
    fun provideGemNftServiceInterface(service: GemNftService): GemNftServiceInterface = service
}
