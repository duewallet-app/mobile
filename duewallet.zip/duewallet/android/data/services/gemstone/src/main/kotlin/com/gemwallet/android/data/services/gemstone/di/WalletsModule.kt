package com.gemwallet.android.data.services.gemstone.di

import android.content.Context
import com.gemwallet.android.data.services.store.LocalStore
import com.gemwallet.android.data.services.store.database.AccountsDao
import com.gemwallet.android.data.services.store.database.AssetsDao
import com.gemwallet.android.data.services.store.database.StoreTransactionRunner
import com.gemwallet.android.data.services.store.database.WalletsDao
import com.gemwallet.android.data.services.gemstone.GemstoneFileStore
import com.gemwallet.android.data.services.gemstone.stores.GemstoneWalletPreferencesStore
import com.gemwallet.android.data.services.gemstone.stores.GemstoneWalletStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import uniffi.gemstone.AlienProvider
import uniffi.gemstone.GemAvatarService
import uniffi.gemstone.GemFileStore
import uniffi.gemstone.GemWalletPreferencesService
import uniffi.gemstone.GemWalletService
import uniffi.gemstone.GemWalletServiceInterface
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object WalletsModule {

    @Provides
    fun provideGemWalletServiceInterface(service: GemWalletService): GemWalletServiceInterface = service

    @Provides
    @Singleton
    fun provideGemFileStore(localStore: LocalStore): GemFileStore = GemstoneFileStore(localStore)

    @Provides
    @Singleton
    fun provideGemWalletPreferencesService(@ApplicationContext context: Context): GemWalletPreferencesService = GemWalletPreferencesService(GemstoneWalletPreferencesStore(context))

    @Provides
    @Singleton
    fun provideGemWalletStore(walletsDao: WalletsDao, accountsDao: AccountsDao, assetsDao: AssetsDao, transactionRunner: StoreTransactionRunner): GemstoneWalletStore =
        GemstoneWalletStore(walletsDao, accountsDao, assetsDao, transactionRunner)

    @Provides
    @Singleton
    fun provideGemAvatarService(walletStore: GemstoneWalletStore, fileStore: GemFileStore, alienProvider: AlienProvider): GemAvatarService = GemAvatarService(
        wallets = walletStore,
        files = fileStore,
        provider = alienProvider,
    )
}
