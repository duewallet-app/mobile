package com.gemwallet.android.data.services.gemstone.di

import com.gemwallet.android.data.services.gemstone.device.GemstoneDevicePlatform
import com.gemwallet.android.data.services.gemstone.stores.GemstoneDeveloperStore
import com.gemwallet.android.data.services.gemstone.stores.GemstoneTransactionStateStore
import com.gemwallet.android.data.services.store.database.AssetsDao
import com.gemwallet.android.data.services.store.database.BannersDao
import com.gemwallet.android.data.services.store.database.PricesDao
import com.gemwallet.android.data.services.store.database.StakeDao
import com.gemwallet.android.data.services.store.database.TransactionsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import uniffi.gemstone.GemDeveloperService
import uniffi.gemstone.GemDeveloperServiceInterface
import uniffi.gemstone.GemPerpetualService
import uniffi.gemstone.GemPreferencesService
import uniffi.gemstone.GemTransactionStateService
import uniffi.gemstone.GemTransactionsService
import uniffi.gemstone.GemWalletPreferencesService

@InstallIn(SingletonComponent::class)
@Module
object DeveloperModule {

    @Provides
    fun provideGemstoneDeveloperStore(transactionsDao: TransactionsDao, assetsDao: AssetsDao, stakeDao: StakeDao, bannersDao: BannersDao, pricesDao: PricesDao): GemstoneDeveloperStore =
        GemstoneDeveloperStore(transactionsDao, assetsDao, stakeDao, bannersDao, pricesDao)

    @Provides
    fun provideGemDeveloperService(
        platform: GemstoneDevicePlatform,
        preferencesService: GemPreferencesService,
        walletPreferencesService: GemWalletPreferencesService,
        transactionStateService: GemTransactionStateService,
        transactionsService: GemTransactionsService,
        perpetualService: GemPerpetualService,
        developerStore: GemstoneDeveloperStore,
    ): GemDeveloperServiceInterface = GemDeveloperService(
        platform,
        preferencesService,
        walletPreferencesService,
        transactionStateService,
        transactionsService,
        perpetualService,
        developerStore,
    )
}
