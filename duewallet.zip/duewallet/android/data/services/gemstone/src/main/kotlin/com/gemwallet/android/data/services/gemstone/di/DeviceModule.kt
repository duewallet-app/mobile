package com.gemwallet.android.data.services.gemstone.di

import android.content.Context
import com.gemwallet.android.application.device.cases.EnablePushForNewWallet
import com.gemwallet.android.application.device.cases.EnablePushForSupport
import com.gemwallet.android.application.device.cases.GetPushEnabled
import com.gemwallet.android.application.device.cases.RequestPushToken
import com.gemwallet.android.application.device.cases.SetPushToken
import com.gemwallet.android.application.device.cases.SwitchPushEnabled
import com.gemwallet.android.data.services.gemstone.device.DeviceObserverService
import com.gemwallet.android.data.services.gemstone.device.DevicePushSettings
import com.gemwallet.android.data.services.gemstone.device.GemstoneDevicePlatform
import com.gemwallet.android.data.services.gemstone.stores.GemstoneWalletStore
import com.gemwallet.android.data.services.store.ConfigStore
import com.gemwallet.android.data.services.store.queries.WalletsQuery
import com.gemwallet.android.model.BuildInfo
import com.gemwallet.android.model.NotificationsAvailable
import dagger.Lazy
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import uniffi.gemstone.GemDeviceApiClient
import uniffi.gemstone.GemDeviceKeyService
import uniffi.gemstone.GemDeviceService
import uniffi.gemstone.GemDeviceServiceInterface
import uniffi.gemstone.GemNotificationPermissions
import uniffi.gemstone.GemNotificationsService
import uniffi.gemstone.GemPreferencesService
import uniffi.gemstone.GemSubscriptionService
import uniffi.gemstone.GemWalletSessionService
import javax.inject.Named
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object DeviceModule {

    @Provides
    @Singleton
    fun provideGemDeviceService(@Named("registration") apiClient: GemDeviceApiClient, subscriptionService: GemSubscriptionService, platform: GemstoneDevicePlatform, preferencesService: GemPreferencesService): GemDeviceService =
        GemDeviceService(apiClient, subscriptionService, platform, preferencesService)

    @Provides
    @Singleton
    fun provideGemSubscriptionService(@Named("registration") apiClient: GemDeviceApiClient, walletSessionService: GemWalletSessionService): GemSubscriptionService = GemSubscriptionService(apiClient, walletSessionService)

    @Provides
    @Singleton
    fun provideGemNotificationsService(deviceService: GemDeviceService, preferencesService: GemPreferencesService, notificationPermissions: GemNotificationPermissions): GemNotificationsService =
        GemNotificationsService(deviceService, preferencesService, notificationPermissions)

    @Provides
    @Singleton
    fun provideDevicePushSettings(@ApplicationContext context: Context, notificationsAvailable: NotificationsAvailable, deviceService: Lazy<GemDeviceService>, notificationsService: Lazy<GemNotificationsService>): DevicePushSettings =
        DevicePushSettings(
            configStore = ConfigStore(context.getSharedPreferences("device-info", Context.MODE_PRIVATE)),
            notificationsAvailable = notificationsAvailable,
            deviceService = deviceService,
            notificationsService = notificationsService,
        )

    @Provides
    @Singleton
    fun provideDevicePlatform(
        @ApplicationContext context: Context,
        buildInfo: BuildInfo,
        deviceKeyService: GemDeviceKeyService,
        preferencesService: GemPreferencesService,
        notificationsAvailable: NotificationsAvailable,
        pushSettings: DevicePushSettings,
        requestPushToken: RequestPushToken,
    ): GemstoneDevicePlatform = GemstoneDevicePlatform(
        context = context,
        deviceKeyService = deviceKeyService,
        pushSettings = pushSettings,
        requestPushToken = requestPushToken,
        platformStore = buildInfo.platformStore,
        notificationsAvailable = notificationsAvailable,
        versionName = buildInfo.versionName,
        preferencesService = preferencesService,
    )

    @Provides
    fun provideSwitchPushEnabledCase(pushSettings: DevicePushSettings): SwitchPushEnabled = pushSettings

    @Provides
    fun provideEnablePushForSupportCase(pushSettings: DevicePushSettings): EnablePushForSupport = pushSettings

    @Provides
    fun provideEnablePushForNewWalletCase(pushSettings: DevicePushSettings): EnablePushForNewWallet = pushSettings

    @Provides
    fun provideGetPushEnabledCase(pushSettings: DevicePushSettings): GetPushEnabled = pushSettings

    @Provides
    fun provideSetPushTokenCase(pushSettings: DevicePushSettings): SetPushToken = pushSettings

    @Provides
    @Singleton
    fun provideDeviceObserverService(walletsQuery: WalletsQuery, deviceService: GemDeviceService): DeviceObserverService = DeviceObserverService(
        walletsQuery = walletsQuery,
        deviceService = deviceService,
    )

    @Provides
    @Singleton
    fun provideDeviceServiceInterface(service: GemDeviceService): GemDeviceServiceInterface = service
}
