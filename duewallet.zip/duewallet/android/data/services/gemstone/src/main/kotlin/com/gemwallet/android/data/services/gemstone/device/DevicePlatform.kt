package com.gemwallet.android.data.services.gemstone.device

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.gemwallet.android.application.device.cases.RequestPushToken
import com.gemwallet.android.ext.model
import com.gemwallet.android.ext.os
import com.gemwallet.android.ext.toGem
import com.gemwallet.android.model.NotificationsAvailable
import com.wallet.core.primitives.Platform
import com.wallet.core.primitives.PlatformStore
import uniffi.gemstone.GemDeviceInfo
import uniffi.gemstone.GemDeviceKeyService
import uniffi.gemstone.GemDeviceKeyServiceInterface
import uniffi.gemstone.GemDevicePlatform
import uniffi.gemstone.GemPreferencesService
import uniffi.gemstone.GemPreferencesServiceInterface
import java.util.Locale

class GemstoneDevicePlatform(
    private val context: Context,
    private val pushSettings: DevicePushSettings,
    private val requestPushToken: RequestPushToken,
    private val platformStore: PlatformStore,
    private val notificationsAvailable: NotificationsAvailable,
    private val versionName: String,
    private val deviceKeyService: GemDeviceKeyServiceInterface,
    private val preferencesService: GemPreferencesServiceInterface,
) : GemDevicePlatform {

    override suspend fun deviceId(): String = deviceKeyService.deviceId()

    override suspend fun deviceInfo(): GemDeviceInfo = GemDeviceInfo(
        platform = Platform.Android.toGem(),
        platformStore = platformStore.toGem(),
        os = Platform.os,
        model = Platform.model,
        version = versionName,
        localeIdentifier = Locale.getDefault().toLanguageTag(),
    )

    override suspend fun pushToken(): String {
        val token = pushSettings.getPushToken()
        if (token.isEmpty()) {
            requestPushToken.requestToken { requested ->
                if (requested.isNotEmpty()) {
                    pushSettings.setPushToken(requested)
                }
            }
        }
        return token
    }

    override suspend fun isPushEnabled(): Boolean = notificationsAvailable &&
        preferencesService.isPushNotificationsEnabled() &&
        NotificationManagerCompat.from(context).areNotificationsEnabled()

    override suspend fun getCurrency(): uniffi.gemstone.Currency = preferencesService.getCurrency()
}
