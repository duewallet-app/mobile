package com.gemwallet.android.data.services.gemstone.stores
import com.gemwallet.android.data.services.store.database.AccountsDao
import com.gemwallet.android.data.services.store.database.AssetsDao
import com.gemwallet.android.data.services.store.database.StoreTransactionRunner
import com.gemwallet.android.data.services.store.database.WalletsDao
import com.gemwallet.android.data.services.store.database.entities.DbAccount
import com.gemwallet.android.data.services.store.database.entities.DbAsset
import com.gemwallet.android.ext.asset
import com.gemwallet.android.testkit.mockAccount
import com.gemwallet.android.testkit.mockAsset
import com.gemwallet.android.testkit.mockAssetId
import com.gemwallet.android.testkit.mockWallet
import com.wallet.core.primitives.Chain
import com.wallet.core.primitives.WalletId
import com.wallet.core.primitives.WalletType
import io.mockk.coEvery
import io.mockk.coJustRun
import io.mockk.coVerifyOrder
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Test

class GemstoneWalletStoreTest {

    private val walletsDao = mockk<WalletsDao>(relaxed = true)
    private val accountsDao = mockk<AccountsDao>(relaxed = true)
    private val assetsDao = mockk<AssetsDao>(relaxed = true)
    private val transactionRunner = RecordingStoreTransactionRunner()

    private val subject = GemstoneWalletStore(
        walletsDao = walletsDao,
        accountsDao = accountsDao,
        assetsDao = assetsDao,
        transactionRunner = transactionRunner,
    )

    @After
    fun tearDown() {
        unmockkAll()
    }

    @Test
    fun addWallet_insertsNativeAssetBeforeAccount() = runBlocking {
        stubNativeAssets()
        every { walletsDao.getById("wallet-1") } returns flowOf(null)
        every { walletsDao.getAll() } returns flowOf(emptyMap())
        coEvery { accountsDao.getByWalletId("wallet-1") } returns emptyList()
        coJustRun { walletsDao.insert(any()) }
        coJustRun { assetsDao.insert(any<List<DbAsset>>()) }
        coJustRun { accountsDao.insert(any<List<DbAccount>>()) }

        subject.addWallet(mockWallet(id = WalletId("wallet-1"), type = WalletType.View, accounts = listOf(mockAccount(chain = Chain.Ethereum, address = "0xabc"))))

        coVerifyOrder {
            walletsDao.insert(any())
            assetsDao.insert(match<List<DbAsset>> { records -> records.map { it.id } == listOf("ethereum") })
            accountsDao.insert(any<List<DbAccount>>())
        }
        assertEquals(1, transactionRunner.runCount)
    }

    private fun stubNativeAssets() {
        mockkStatic("com.gemwallet.android.ext.ChainKt")
        mockkStatic("uniffi.gemstone.GemstoneKt")

        every { Chain.Ethereum.asset() } returns mockAsset(id = mockAssetId(chain = Chain.Ethereum), name = "Ethereum", symbol = "ETH", decimals = 18u)
        every { Chain.Solana.asset() } returns mockAsset(id = mockAssetId(chain = Chain.Solana), name = "Solana", symbol = "SOL", decimals = 9u)
    }

    private class RecordingStoreTransactionRunner : StoreTransactionRunner {
        var runCount = 0

        override suspend fun <T> run(block: suspend () -> T): T {
            runCount += 1
            return block()
        }
    }
}
