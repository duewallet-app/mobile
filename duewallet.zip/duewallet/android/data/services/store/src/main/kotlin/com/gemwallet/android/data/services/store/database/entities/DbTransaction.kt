package com.gemwallet.android.data.services.store.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.gemwallet.android.ext.hash
import com.wallet.core.primitives.AssetId
import com.wallet.core.primitives.Transaction
import com.wallet.core.primitives.TransactionDirection
import com.wallet.core.primitives.TransactionId
import com.wallet.core.primitives.TransactionState
import com.wallet.core.primitives.TransactionType
import com.wallet.core.primitives.WalletId

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(DbWallet::class, ["id"], ["walletId"], onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE),
    ],
    indices = [Index(value = ["walletId", "id"], unique = true), Index(value = ["walletId", "createdAt"])],
)
data class DbTransaction(
    val id: TransactionId,
    val walletId: WalletId,
    val hash: String,
    val assetId: AssetId,
    val feeAssetId: AssetId,
    val owner: String,
    val recipient: String,
    val contract: String? = null,
    val metadata: String? = null,
    val state: TransactionState,
    val type: TransactionType,
    val blockNumber: String,
    val sequence: String,
    val fee: String,
    val value: String,
    val payload: String? = null,
    val direction: TransactionDirection,
    val createdAt: Long,
    val updatedAt: Long,
    @ColumnInfo(name = "estimatedConfirmationInSeconds")
    val confirmationEtaSeconds: Long? = null,
    @PrimaryKey(autoGenerate = true) val recordId: Long = 0,
)

fun Transaction.toRecord(walletId: WalletId): DbTransaction = DbTransaction(
    id = this.id,
    walletId = walletId,
    hash = this.hash,
    assetId = this.assetId,
    feeAssetId = this.feeAssetId,
    owner = this.from,
    recipient = this.to,
    contract = this.contract,
    type = this.type,
    state = this.state,
    blockNumber = this.blockNumber ?: "",
    sequence = this.sequence ?: "",
    fee = this.fee,
    value = this.value,
    payload = this.memo,
    metadata = this.metadata,
    direction = this.direction,
    updatedAt = System.currentTimeMillis(),
    createdAt = this.createdAt,
    confirmationEtaSeconds = null,
)

fun DbTransaction.toDTO(): Transaction = Transaction(
    id = this.id,
    assetId = this.assetId,
    from = this.owner,
    to = this.recipient,
    contract = this.contract,
    type = this.type,
    state = this.state,
    blockNumber = this.blockNumber,
    sequence = this.sequence,
    fee = this.fee,
    feeAssetId = this.feeAssetId,
    value = this.value,
    memo = this.payload,
    direction = this.direction,
    utxoInputs = emptyList(),
    utxoOutputs = emptyList(),
    createdAt = this.createdAt,
    metadata = this.metadata,
)

fun List<DbTransaction>.toDTO() = map { it.toDTO() }

fun List<Transaction>.toRecord(walletId: WalletId) = map { it.toRecord(walletId) }
