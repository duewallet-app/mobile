package com.gemwallet.android.data.services.store.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.wallet.core.primitives.Wallet
import com.wallet.core.primitives.WalletId
import com.wallet.core.primitives.WalletListItem
import com.wallet.core.primitives.WalletSource
import com.wallet.core.primitives.WalletType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "wallets")
data class DbWallet(
    @PrimaryKey val id: String,
    val name: String,
    @ColumnInfo(name = "domain_name") val domainName: String?,
    val type: WalletType,
    val position: Int,
    val pinned: Boolean,
    val index: Int,
    @ColumnInfo(defaultValue = "Import") val source: WalletSource,
    val imageUrl: String? = null,
)

fun DbWallet.toDTO(accounts: List<DbAccount>): Wallet = Wallet(
    id = WalletId(id),
    name = name,
    type = type,
    accounts = accounts.map { it.toAccount() },
    index = index,
    isPinned = pinned,
    imageUrl = imageUrl,
    source = source,
)

fun DbWallet.toWalletListItem(): WalletListItem = WalletListItem(
    id = WalletId(id),
    name = name,
    index = index,
    isPinned = pinned,
    imageUrl = imageUrl,
)

fun Wallet.toRecord(): DbWallet = DbWallet(
    id = id.id,
    name = name,
    type = type,
    domainName = null,
    position = 0,
    pinned = isPinned,
    index = index,
    source = source,
    imageUrl = imageUrl,
)

fun Map<DbWallet, List<DbAccount>>.toDTO() = map { entry -> entry.key.toDTO(entry.value) }

fun Flow<Map<DbWallet, List<DbAccount>>>.toDTO() = map { entry -> entry.toDTO() }
