package com.gemwallet.android.data.services.store.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.gemwallet.android.data.services.store.database.entities.DbAccount
import com.gemwallet.android.data.services.store.database.entities.DbAddress
import com.gemwallet.android.data.services.store.database.entities.DbAsset
import com.gemwallet.android.data.services.store.database.entities.DbAssetLink
import com.gemwallet.android.data.services.store.database.entities.DbAssetList
import com.gemwallet.android.data.services.store.database.entities.DbAssetMarket
import com.gemwallet.android.data.services.store.database.entities.DbBalance
import com.gemwallet.android.data.services.store.database.entities.DbBanner
import com.gemwallet.android.data.services.store.database.entities.DbConnection
import com.gemwallet.android.data.services.store.database.entities.DbContact
import com.gemwallet.android.data.services.store.database.entities.DbContactAddress
import com.gemwallet.android.data.services.store.database.entities.DbDelegationBase
import com.gemwallet.android.data.services.store.database.entities.DbDelegationValidator
import com.gemwallet.android.data.services.store.database.entities.DbFiatRate
import com.gemwallet.android.data.services.store.database.entities.DbFiatTransaction
import com.gemwallet.android.data.services.store.database.entities.DbInAppNotification
import com.gemwallet.android.data.services.store.database.entities.DbNFTAsset
import com.gemwallet.android.data.services.store.database.entities.DbNFTAssociation
import com.gemwallet.android.data.services.store.database.entities.DbNFTCollection
import com.gemwallet.android.data.services.store.database.entities.DbNode
import com.gemwallet.android.data.services.store.database.entities.DbPerpetual
import com.gemwallet.android.data.services.store.database.entities.DbPerpetualPosition
import com.gemwallet.android.data.services.store.database.entities.DbPrice
import com.gemwallet.android.data.services.store.database.entities.DbPriceAlert
import com.gemwallet.android.data.services.store.database.entities.DbRecentActivity
import com.gemwallet.android.data.services.store.database.entities.DbSearch
import com.gemwallet.android.data.services.store.database.entities.DbSupportMessage
import com.gemwallet.android.data.services.store.database.entities.DbTransaction
import com.gemwallet.android.data.services.store.database.entities.DbTransactionAsset
import com.gemwallet.android.data.services.store.database.entities.DbWallet

@Database(
    version = 103,
    entities = [
        DbWallet::class,
        DbAccount::class,
        DbAddress::class,
        DbContact::class,
        DbContactAddress::class,
        DbAsset::class,
        DbBalance::class,
        DbPrice::class,
        DbTransaction::class,
        DbTransactionAsset::class,
        DbConnection::class,
        DbDelegationValidator::class,
        DbDelegationBase::class,
        DbNode::class,
        DbBanner::class,
        DbPriceAlert::class,
        DbNFTCollection::class,
        DbNFTAsset::class,
        DbNFTAssociation::class,
        DbAssetLink::class,
        DbAssetMarket::class,
        DbAssetList::class,
        DbSearch::class,
        DbFiatRate::class,
        DbFiatTransaction::class,
        DbRecentActivity::class,
        DbPerpetual::class,
        DbPerpetualPosition::class,
        DbInAppNotification::class,
        DbSupportMessage::class,
    ],
)
@TypeConverters(StoreConverters::class, ChainConverters::class)
abstract class GemDatabase : RoomDatabase() {
    abstract fun walletsDao(): WalletsDao

    abstract fun accountsDao(): AccountsDao

    abstract fun addressesDao(): AddressesDao

    abstract fun contactsDao(): ContactsDao

    abstract fun assetsDao(): AssetsDao

    abstract fun balancesDao(): BalancesDao

    abstract fun pricesDao(): PricesDao

    abstract fun transactionsDao(): TransactionsDao

    abstract fun connectionsDao(): ConnectionsDao

    abstract fun stakeDao(): StakeDao

    abstract fun nodeDao(): NodesDao

    abstract fun bannersDao(): BannersDao

    abstract fun priceAlertsDao(): PriceAlertsDao

    abstract fun nftDao(): NftDao

    abstract fun searchDao(): SearchDao

    abstract fun assetListDao(): AssetListDao

    abstract fun perpetualDao(): PerpetualDao

    abstract fun perpetualPositionDao(): PerpetualPositionDao

    abstract fun fiatTransactionsDao(): FiatTransactionsDao

    abstract fun inAppNotificationsDao(): InAppNotificationsDao

    abstract fun supportMessagesDao(): SupportMessagesDao
}
