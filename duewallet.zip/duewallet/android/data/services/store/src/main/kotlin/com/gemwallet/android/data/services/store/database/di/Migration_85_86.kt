package com.gemwallet.android.data.services.store.database.di

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object Migration_85_86 : Migration(85, 86) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `contacts` ADD COLUMN `imageUrl` TEXT")
        db.execSQL("ALTER TABLE `addresses` ADD COLUMN `imageUrl` TEXT")
    }
}
