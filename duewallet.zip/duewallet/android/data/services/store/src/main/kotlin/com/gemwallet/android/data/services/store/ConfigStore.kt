package com.gemwallet.android.data.services.store

import android.content.SharedPreferences
import androidx.core.content.edit

class ConfigStore(var store: SharedPreferences) {
    fun getInt(key: String, postfix: String = "") = store.getInt(buildKey(key, postfix), 0)

    fun getString(key: String, postfix: String = "") = store.getString(buildKey(key, postfix), "") ?: ""

    fun getBoolean(key: String, default: Boolean = false) = store.getBoolean(buildKey(key), default)

    fun putInt(key: String, value: Int, postfix: String = "") {
        store.edit { putInt(buildKey(key, postfix), value) }
    }

    fun putString(key: String, value: String, postfix: String = "") {
        store.edit { putString(buildKey(key, postfix), value) }
    }

    fun getLong(key: String, postfix: String = "") = store.getLong(buildKey(key, postfix), 0L)

    fun putLong(key: String, value: Long, postfix: String = "") {
        store.edit { putLong(buildKey(key, postfix), value) }
    }

    fun putBoolean(key: String, value: Boolean) {
        store.edit { putBoolean(buildKey(key), value) }
    }

    fun remove(key: String, postfix: String = "") {
        store.edit { remove(buildKey(key, postfix)) }
    }

    private fun buildKey(key: String, postfix: String = "") = "$key-$postfix"
}
