package com.gemwallet.android.data.services.store.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.gemwallet.android.data.services.store.database.entities.DbInAppNotification
import kotlinx.coroutines.flow.Flow

@Dao
interface InAppNotificationsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(notifications: List<DbInAppNotification>)

    @Query("SELECT * FROM in_app_notifications WHERE wallet_id = :walletId ORDER BY created_at DESC")
    fun getNotifications(walletId: String): Flow<List<DbInAppNotification>>

    @Query("UPDATE in_app_notifications SET read_at = :readAt WHERE wallet_id = :walletId AND read_at IS NULL AND created_at < :createdBefore")
    suspend fun markRead(walletId: String, createdBefore: Long, readAt: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM in_app_notifications WHERE wallet_id = :walletId AND read_at IS NULL)")
    suspend fun hasUnread(walletId: String): Boolean
}
