package com.gemwallet.android.data.services.store.integration

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.gemwallet.android.data.services.store.database.entities.toRecord
import com.gemwallet.android.data.services.store.database.mockGemDatabase
import com.gemwallet.android.data.services.store.queries.TransactionsQuery
import com.gemwallet.android.ext.toIdentifier
import com.gemwallet.android.ext.toPrimitives
import com.gemwallet.android.testkit.mockAsset
import com.gemwallet.android.testkit.mockAssetId
import com.gemwallet.android.testkit.mockTransaction
import com.gemwallet.android.testkit.mockTransactionId
import com.gemwallet.android.testkit.mockTransactionsFilter
import com.gemwallet.android.testkit.mockWallet
import com.wallet.core.primitives.AssetType
import com.wallet.core.primitives.Chain
import com.wallet.core.primitives.Transaction
import com.wallet.core.primitives.TransactionDirection
import com.wallet.core.primitives.TransactionState
import com.wallet.core.primitives.TransactionType
import com.wallet.core.primitives.WalletId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import uniffi.gemstone.GemTransactionFilter
import uniffi.gemstone.activityFilters
import uniffi.gemstone.pendingActivityFilters

@RunWith(AndroidJUnit4::class)
class TransactionsQueryTest {
    private val database = mockGemDatabase()
    private val query = TransactionsQuery(database.transactionsDao())
    private val wallet = mockWallet(id = WalletId("wallet-1"))
    private val otherWallet = mockWallet(id = WalletId("wallet-2"))
    private val bitcoin = mockAsset(id = mockAssetId(chain = Chain.Bitcoin), name = "Bitcoin", symbol = "BTC", decimals = 8u)
    private val ethereum = mockAsset(id = mockAssetId(chain = Chain.Ethereum), name = "Ethereum", symbol = "ETH", decimals = 18u)
    private val spam = mockAsset(id = mockAssetId(chain = Chain.Ethereum, tokenId = "0xspam"), name = "Spam", symbol = "SPAM", decimals = 18u, type = AssetType.ERC20)
    private val received = mockTransaction(
        assetId = bitcoin.id,
        id = mockTransactionId(chain = Chain.Bitcoin, hash = "received"),
        from = "bc1qsender",
        to = "bc1qrecipient",
        value = "123456789012345678901234567890",
        direction = TransactionDirection.Incoming,
        createdAt = 100,
        state = TransactionState.Confirmed,
        feeAssetId = bitcoin.id,
    )
    private val swap =
        mockTransaction(assetId = ethereum.id, id = mockTransactionId(chain = Chain.Ethereum, hash = "swap"), type = TransactionType.Swap, state = TransactionState.Pending, value = "42", createdAt = 300, feeAssetId = ethereum.id)
    private val airdrop = mockTransaction(assetId = spam.id, id = mockTransactionId(chain = Chain.Ethereum, hash = "airdrop"), feeAssetId = ethereum.id, createdAt = 400, state = TransactionState.Confirmed)
    private val failed = mockTransaction(assetId = ethereum.id, id = mockTransactionId(chain = Chain.Ethereum, hash = "failed"), state = TransactionState.Failed, value = "7", createdAt = 200, feeAssetId = ethereum.id)
    private val otherWalletSend = mockTransaction(assetId = bitcoin.id, id = mockTransactionId(chain = Chain.Bitcoin, hash = "other"), value = "9", createdAt = 500, state = TransactionState.Confirmed, feeAssetId = bitcoin.id)

    @Before
    fun setUp() = runBlocking(Dispatchers.IO) {
        database.walletsDao().insert(wallet.toRecord())
        database.walletsDao().insert(otherWallet.toRecord())
        database.assetsDao().insert(listOf(bitcoin.toRecord().copy(rank = 100), ethereum.toRecord().copy(rank = 90), spam.toRecord().copy(rank = 5)))
        database.transactionsDao().insert(listOf(received, swap, airdrop, failed).toRecord(wallet.id) + listOf(otherWalletSend).toRecord(otherWallet.id))
        database.transactionsDao().replaceTransactionAssets(listOf(received, swap, airdrop, failed, otherWalletSend).associate { it.id.identifier to listOf(it.assetId.toIdentifier()) })
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun theActivityListsTheWalletTransactionsNewestFirstWithoutLowRankAssets() = runBlocking(Dispatchers.IO) {
        val items = query(wallet.id, activityFilters(emptyList(), emptyList()).toPrimitives(), 1000).first()

        assertEquals(listOf(swap, failed, received).map { it.stored() }, items.map { it.transaction })
        assertEquals(listOf(ethereum, ethereum, bitcoin), items.map { it.asset })
    }

    @Test
    fun withoutFiltersEveryWalletTransactionIsListed() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(airdrop, swap, failed, received).map { it.stored() }, query(wallet.id, null, 1000).first().map { it.transaction })
    }

    @Test
    fun anotherWalletSeesOnlyItsOwnTransactions() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(otherWalletSend.stored()), query(otherWallet.id, activityFilters(emptyList(), emptyList()).toPrimitives(), 1000).first().map { it.transaction })
    }

    @Test
    fun theChainAndTypeFiltersNarrowTheActivity() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(received.stored()), query(wallet.id, activityFilters(listOf(Chain.Bitcoin).map { it.string }, emptyList()).toPrimitives(), 1000).first().map { it.transaction })
        assertEquals(listOf(swap.stored()), query(wallet.id, activityFilters(emptyList(), listOf(GemTransactionFilter.SWAPS)).toPrimitives(), 1000).first().map { it.transaction })
        assertEquals(listOf(failed.stored(), received.stored()), query(wallet.id, activityFilters(emptyList(), listOf(GemTransactionFilter.TRANSFERS)).toPrimitives(), 1000).first().map { it.transaction })
    }

    @Test
    fun theAssetFilterListsTheTransactionsOfThatAssetOnly() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(swap, failed).map { it.stored() }, query(wallet.id, mockTransactionsFilter(assetId = ethereum.id), 1000).first().map { it.transaction })
        assertEquals(listOf(airdrop.stored()), query(wallet.id, mockTransactionsFilter(assetId = spam.id), 1000).first().map { it.transaction })
    }

    @Test
    fun theAssetFilterIncludesTransactionsThatTouchTheAsset() = runBlocking(Dispatchers.IO) {
        database.transactionsDao().replaceTransactionAssets(mapOf(swap.id.identifier to listOf(ethereum.id.toIdentifier(), bitcoin.id.toIdentifier())))

        assertEquals(listOf(swap, received).map { it.stored() }, query(wallet.id, mockTransactionsFilter(assetId = bitcoin.id), 1000).first().map { it.transaction })
    }

    @Test
    fun theAssetFilterSkipsATransactionWhoseMainAssetHasNoAssetRow() = runBlocking(Dispatchers.IO) {
        database.transactionsDao().replaceTransactionAssets(mapOf(swap.id.identifier to listOf(bitcoin.id.toIdentifier())))

        assertEquals(listOf(failed.stored()), query(wallet.id, mockTransactionsFilter(assetId = ethereum.id), 1000).first().map { it.transaction })
    }

    @Test
    fun theStateFilterKeepsOnlyThoseStates() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(swap.stored()), query(wallet.id, pendingActivityFilters().toPrimitives(), 1000).first().map { it.transaction })
        assertEquals(listOf(failed.stored()), query(wallet.id, mockTransactionsFilter(states = listOf(TransactionState.Failed)), 1000).first().map { it.transaction })
    }

    @Test
    fun theLimitKeepsTheNewestTransactions() = runBlocking(Dispatchers.IO) {
        assertEquals(listOf(airdrop, swap).map { it.stored() }, query(wallet.id, null, 2).first().map { it.transaction })
    }

    @Test
    fun aConfirmedTransactionLeavesThePendingActivity() = runBlocking(Dispatchers.IO) {
        val pending = pendingActivityFilters().toPrimitives()
        assertEquals(listOf(swap.stored()), query(wallet.id, pending, 1000).first().map { it.transaction })

        database.transactionsDao().updateTransactionState(swap.id, wallet.id, TransactionState.Confirmed, fee = null, value = null, blockNumber = null, metadata = null, confirmationEtaSeconds = null)

        assertEquals(emptyList<Transaction>(), query(wallet.id, pending, 1000).first().map { it.transaction })
    }

    private fun Transaction.stored(): Transaction = copy(blockNumber = blockNumber.orEmpty(), sequence = "", utxoInputs = emptyList(), utxoOutputs = emptyList())
}
