package com.gemwallet.android.data.services.store.integration

import androidx.room.migration.Migration
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.gemwallet.android.data.services.store.database.di.Migration_96_98
import com.gemwallet.android.data.services.store.database.di.Migration_97_98
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class Migration_97_98Test {
    private val testDb = "migration-97-98-test"

    @get:Rule
    val helper = gemDatabaseMigrationTestHelper()

    @Before
    fun setUp() {
        InstrumentationRegistry.getInstrumentation().targetContext.deleteDatabase(testDb)
    }

    @Test
    fun theMarketTableIsRecreatedEmptyFrom96() = assertRecreated(96, Migration_96_98)

    @Test
    fun theMarketTableIsRecreatedEmptyFrom97() = assertRecreated(97, Migration_97_98)

    private fun assertRecreated(version: Int, migration: Migration) {
        helper.createDatabase(testDb, version).use { database ->
            database.execSQL(
                "INSERT INTO asset (id, name, symbol, decimals, type, chain, rank, is_enabled, is_buy_enabled, is_sell_enabled, is_swap_enabled, is_stake_enabled, is_earn_enabled, has_image) " +
                    "VALUES ('bitcoin', 'Bitcoin', 'BTC', 8, 'NATIVE', 'bitcoin', 1, 1, 0, 0, 0, 0, 0, 0)",
            )
            database.execSQL("INSERT INTO asset_market (asset_id, marketCap) VALUES ('bitcoin', 900.0)")
        }

        helper.runMigrationsAndValidate(testDb, 98, true, migration).use { database ->
            database.query("SELECT COUNT(*) FROM asset_market").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
        }
    }
}
