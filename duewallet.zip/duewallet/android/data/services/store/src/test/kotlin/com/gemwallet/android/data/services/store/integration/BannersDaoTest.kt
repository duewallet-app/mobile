package com.gemwallet.android.data.services.store.integration

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.gemwallet.android.data.services.store.database.GemDatabase
import com.gemwallet.android.data.services.store.database.entities.DbBanner
import com.gemwallet.android.data.services.store.database.entities.toDTO
import com.gemwallet.android.data.services.store.database.entities.toRecord
import com.gemwallet.android.data.services.store.database.mockGemDatabase
import com.gemwallet.android.ext.toIdentifier
import com.gemwallet.android.testkit.mockAsset
import com.gemwallet.android.testkit.mockAssetId
import com.gemwallet.android.testkit.mockWallet
import com.wallet.core.primitives.BannerEvent
import com.wallet.core.primitives.BannerState
import com.wallet.core.primitives.Chain
import com.wallet.core.primitives.WalletId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BannersDaoTest {
    private lateinit var database: GemDatabase
    private val asset = mockAsset(id = mockAssetId(chain = Chain.Tron), name = "Tron", symbol = "TRX", decimals = 6u)
    private val warning = DbBanner(
        id = "tron-multisignature",
        walletId = "wallet-1",
        assetId = asset.id.toIdentifier(),
        state = BannerState.AlwaysActive,
        event = BannerEvent.AccountBlockedMultiSignature,
    )

    @Before
    fun setUp() = runBlocking(Dispatchers.IO) {
        database = mockGemDatabase()
        database.assetsDao().insert(asset.toRecord())
        WALLET_IDS.forEach { id -> database.walletsDao().insert(mockWallet(id = WalletId(id)).toRecord()) }
        database.bannersDao().saveBanner(warning)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun walletWarningIncludesStoredAsset() = runBlocking(Dispatchers.IO) {
        val banner = database.bannersDao()
            .observeWalletBanners("wallet-1", listOf(BannerEvent.AccountBlockedMultiSignature))
            .first().single().toDTO()

        assertEquals(asset, banner.asset)
    }

    @Test
    fun deletingTheWalletDeletesItsBanners() = runBlocking(Dispatchers.IO) {
        database.walletsDao().delete(mockWallet(id = WalletId("wallet-1")).toRecord())

        assertNull(database.bannersDao().getBanner(warning.id))
    }

    @Test
    fun walletKeepsAssetlessOnboarding() = runBlocking(Dispatchers.IO) {
        database.bannersDao().saveBanner(warning.copy(id = "onboarding", assetId = null, event = BannerEvent.Onboarding))
        val banner = database.bannersDao()
            .observeWalletBanners("wallet-1", listOf(BannerEvent.Onboarding))
            .first().single().toDTO()

        assertEquals(BannerEvent.Onboarding, banner.event)
        assertNull(banner.asset)
    }

    private companion object {
        val WALLET_IDS = listOf("wallet-1")
    }
}
