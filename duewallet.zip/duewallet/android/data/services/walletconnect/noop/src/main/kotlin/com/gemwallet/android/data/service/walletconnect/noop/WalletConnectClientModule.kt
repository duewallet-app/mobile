package com.gemwallet.android.data.service.walletconnect.noop

import com.gemwallet.android.application.wallet_connect.WalletConnectClient
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class WalletConnectClientModule {
    @Binds
    @Singleton
    abstract fun bindWalletConnectClient(client: NoopWalletConnectClient): WalletConnectClient
}
