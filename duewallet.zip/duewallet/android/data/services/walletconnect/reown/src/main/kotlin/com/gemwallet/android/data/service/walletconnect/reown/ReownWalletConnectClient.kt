package com.gemwallet.android.data.service.walletconnect.reown

import android.app.Application
import android.content.Context
import android.util.Log
import com.gemwallet.android.application.wallet_connect.WalletConnectAuthObject
import com.gemwallet.android.application.wallet_connect.WalletConnectAuthPayloadParams
import com.gemwallet.android.application.wallet_connect.WalletConnectAuthenticationRequest
import com.gemwallet.android.application.wallet_connect.WalletConnectClient
import com.gemwallet.android.application.wallet_connect.WalletConnectEvent
import com.gemwallet.android.application.wallet_connect.WalletConnectJsonRpcRequest
import com.gemwallet.android.application.wallet_connect.WalletConnectJsonRpcResponse
import com.gemwallet.android.application.wallet_connect.WalletConnectProposalNamespace
import com.gemwallet.android.application.wallet_connect.WalletConnectSession
import com.gemwallet.android.application.wallet_connect.WalletConnectSessionNamespace
import com.gemwallet.android.application.wallet_connect.WalletConnectSessionProposal
import com.gemwallet.android.application.wallet_connect.WalletConnectSessionRequest
import com.gemwallet.android.application.wallet_connect.WalletConnectValidation
import com.gemwallet.android.application.wallet_connect.WalletConnectVerifyContext
import com.gemwallet.android.ext.toPrimitives
import com.reown.android.Core
import com.reown.android.CoreClient
import com.reown.android.relay.ConnectionType
import com.reown.walletkit.client.Wallet
import com.reown.walletkit.client.WalletKit
import com.wallet.core.primitives.ApplicationMetadata
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import uniffi.gemstone.Config
import uniffi.gemstone.GemWalletConnectRejection
import uniffi.gemstone.GemWalletConnectService
import uniffi.gemstone.GemWalletConnectServiceInterface
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReownWalletConnectClient @Inject constructor(@param:ApplicationContext private val context: Context, private val walletConnectService: GemWalletConnectServiceInterface) :
    WalletConnectClient,
    WalletKit.WalletDelegate,
    CoreClient.CoreDelegate {

    override val isEnabled: Boolean = true

    private val walletEvents = MutableSharedFlow<WalletConnectEvent>(
        replay = 1,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    override val events: SharedFlow<WalletConnectEvent> = walletEvents.asSharedFlow()

    override fun initialize(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val config = Config().getWalletConnectConfig()
        CoreClient.initialize(
            application = context as Application,
            projectId = config.projectId,
            metaData = Core.Model.AppMetaData(
                name = config.appName,
                description = config.appDescription,
                url = config.appUrl,
                icons = config.appIcons,
                redirect = "https://gemwallet.com/wc/",
            ),
            connectionType = ConnectionType.AUTOMATIC,
            telemetryEnabled = false,
        ) { error ->
            onError(error.throwable.message.orEmpty())
        }
        WalletKit.initialize(
            params = Wallet.Params.Init(core = CoreClient),
            onSuccess = {
                CoreClient.setDelegate(this)
                WalletKit.setWalletDelegate(this)
                onSuccess()
            },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun activeSessions(): List<WalletConnectSession> = WalletKit.getListOfActiveSessions().map { it.toWalletConnectSession() }

    override fun pendingSessionRequests(topic: String): List<WalletConnectSessionRequest> = WalletKit.getPendingListOfSessionRequests(topic).map { it.toWalletConnectSessionRequest() }

    override fun verifyContext(id: Long): WalletConnectVerifyContext? = WalletKit.getVerifyContext(id)?.toWalletConnectVerifyContext()

    override fun pingSession(topic: String) {
        WalletKit.pingSession(Wallet.Params.Ping(topic), null)
    }

    override fun disconnectSession(topic: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.disconnectSession(
            params = Wallet.Params.SessionDisconnect(topic),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun pair(uri: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.pair(
            params = Wallet.Params.Pair(uri),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun generateApprovedNamespaces(proposal: WalletConnectSessionProposal, supportedNamespaces: Map<String, WalletConnectSessionNamespace>): Map<String, WalletConnectSessionNamespace> {
        val sessionProposal = proposal.pendingReownProposal() ?: return supportedNamespaces
        return WalletKit.generateApprovedNamespaces(
            sessionProposal = sessionProposal,
            supportedNamespaces = supportedNamespaces.mapValues { it.value.toReownSessionNamespace() },
        ).mapValues { it.value.toWalletConnectSessionNamespace() }
    }

    override fun approveSession(proposal: WalletConnectSessionProposal, namespaces: Map<String, WalletConnectSessionNamespace>, properties: Map<String, String>, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val sessionProposal = proposal.pendingReownProposal()
        if (sessionProposal == null) {
            onError("Session proposal expired")
            return
        }
        WalletKit.approveSession(
            params = Wallet.Params.SessionApprove(
                proposerPublicKey = sessionProposal.proposerPublicKey,
                namespaces = namespaces.mapValues { it.value.toReownSessionNamespace() },
                properties = properties,
            ),
            onError = { onError(it.throwable.message ?: "Unknown error") },
            onSuccess = { onSuccess() },
        )
    }

    override fun rejectSession(proposal: WalletConnectSessionProposal, rejection: GemWalletConnectRejection, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val sessionProposal = proposal.pendingReownProposal()
        if (sessionProposal == null) {
            onSuccess()
            return
        }
        WalletKit.rejectSession(
            params = Wallet.Params.SessionReject(
                proposerPublicKey = sessionProposal.proposerPublicKey,
                reason = rejection.message,
            ),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun updateSession(topic: String, namespaces: Map<String, WalletConnectSessionNamespace>, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.updateSession(
            params = Wallet.Params.SessionUpdate(
                sessionTopic = topic,
                namespaces = namespaces.mapValues { it.value.toReownSessionNamespace() },
            ),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun approveAuthentication(request: WalletConnectAuthenticationRequest, auths: List<WalletConnectAuthObject>, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.approveSessionAuthenticate(
            params = Wallet.Params.ApproveSessionAuthenticate(
                id = request.id,
                auths = auths.map { (it as ReownAuthObject).value },
            ),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message ?: "Authentication failed") },
        )
    }

    override fun rejectAuthentication(request: WalletConnectAuthenticationRequest, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.rejectSessionAuthenticate(
            params = Wallet.Params.RejectSessionAuthenticate(
                id = request.id,
                reason = "Reject Session Authentication",
            ),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun respondSessionRequest(topic: String, id: Long, response: WalletConnectJsonRpcResponse, onSuccess: () -> Unit, onError: (String) -> Unit) {
        WalletKit.respondSessionRequest(
            params = Wallet.Params.SessionRequestResponse(
                sessionTopic = topic,
                jsonRpcResponse = when (response) {
                    is WalletConnectJsonRpcResponse.Result -> Wallet.Model.JsonRpcResponse.JsonRpcResult(id, response.payload)
                    is WalletConnectJsonRpcResponse.Error -> Wallet.Model.JsonRpcResponse.JsonRpcError(id, response.code, response.message)
                },
            ),
            onSuccess = { onSuccess() },
            onError = { onError(it.throwable.message.orEmpty()) },
        )
    }

    override fun generateAuthPayloadParams(payloadParams: WalletConnectAuthPayloadParams, supportedChains: List<String>, supportedMethods: List<String>): WalletConnectAuthPayloadParams {
        val result = WalletKit.generateAuthPayloadParams(
            payloadParams = payloadParams.toReownPayloadAuthRequestParams(),
            supportedChains = supportedChains,
            supportedMethods = supportedMethods,
        )
        return result.toWalletConnectAuthPayloadParams()
    }

    override fun formatAuthMessage(payloadParams: WalletConnectAuthPayloadParams, issuer: String): String = WalletKit.formatAuthMessage(
        Wallet.Params.FormatAuthMessage(
            payloadParams = payloadParams.toReownPayloadAuthRequestParams(),
            issuer = issuer,
        ),
    )

    override fun generateAuthObject(payloadParams: WalletConnectAuthPayloadParams, issuer: String, signature: String): WalletConnectAuthObject = ReownAuthObject(
        WalletKit.generateAuthObject(
            payloadParams = payloadParams.toReownPayloadAuthRequestParams(),
            issuer = issuer,
            signature = Wallet.Model.Cacao.Signature(
                t = "eip191",
                s = signature,
            ),
        ),
    )

    override val onSessionAuthenticate: (Wallet.Model.SessionAuthenticate, Wallet.Model.VerifyContext) -> Unit = { request, verifyContext ->
        walletEvents.tryEmit(WalletConnectEvent.AuthenticationRequest(request.toWalletConnectAuthenticationRequest(), verifyContext.toWalletConnectVerifyContext()))
    }

    override fun onConnectionStateChange(state: Wallet.Model.ConnectionState) = Unit
    override fun onError(error: Wallet.Model.Error) {
        Log.e(TAG, "Reown wallet error", error.throwable)
    }
    override fun onProposalExpired(proposal: Wallet.Model.ExpiredProposal) = Unit
    override fun onRequestExpired(request: Wallet.Model.ExpiredRequest) {
        walletEvents.tryEmit(WalletConnectEvent.RequestExpired(request.topic, request.id))
    }

    override fun onSessionDelete(sessionDelete: Wallet.Model.SessionDelete) {
        if (sessionDelete is Wallet.Model.SessionDelete.Success) {
            walletEvents.tryEmit(WalletConnectEvent.SessionDeleted(sessionDelete.topic))
        }
    }

    override fun onSessionExtend(session: Wallet.Model.Session) {
        walletEvents.tryEmit(WalletConnectEvent.SessionChanged(session.topic))
    }

    override fun onSessionProposal(sessionProposal: Wallet.Model.SessionProposal, verifyContext: Wallet.Model.VerifyContext) {
        walletEvents.tryEmit(WalletConnectEvent.SessionProposal(sessionProposal.toWalletConnectSessionProposal(), verifyContext.toWalletConnectVerifyContext()))
    }

    override fun onSessionRequest(sessionRequest: Wallet.Model.SessionRequest, verifyContext: Wallet.Model.VerifyContext) {
        walletEvents.tryEmit(WalletConnectEvent.SessionRequest(sessionRequest.toWalletConnectSessionRequest(), verifyContext.toWalletConnectVerifyContext()))
    }

    override fun onSessionSettleResponse(settleSessionResponse: Wallet.Model.SettledSessionResponse) {
        if (settleSessionResponse is Wallet.Model.SettledSessionResponse.Result) {
            walletEvents.tryEmit(WalletConnectEvent.SessionSettled(settleSessionResponse.session.toWalletConnectSession()))
        }
    }

    override fun onSessionUpdateResponse(sessionUpdateResponse: Wallet.Model.SessionUpdateResponse) {
        if (sessionUpdateResponse is Wallet.Model.SessionUpdateResponse.Result) {
            walletEvents.tryEmit(WalletConnectEvent.SessionChanged(sessionUpdateResponse.topic))
        }
    }

    private fun Wallet.Model.Session.toWalletConnectSession(): WalletConnectSession = WalletConnectSession(
        topic = topic,
        expiry = expiry,
        metadata = metaData?.toApplicationMetadata(),
        namespaces = namespaces.mapValues { it.value.toWalletConnectSessionNamespace() },
        redirect = redirect,
    )

    private fun Wallet.Model.SessionAuthenticate.toWalletConnectAuthenticationRequest(): WalletConnectAuthenticationRequest = WalletConnectAuthenticationRequest(
        id = id,
        metadata = participant.metadata?.toApplicationMetadata(),
        payloadParams = payloadParams.toWalletConnectAuthPayloadParams(),
    )

    private fun Core.Model.AppMetaData.toApplicationMetadata(): ApplicationMetadata = walletConnectService.applicationMetadata(name, description, url, icons).toPrimitives()

    private fun WalletConnectSessionProposal.pendingReownProposal(): Wallet.Model.SessionProposal? = WalletKit.getSessionProposals().firstOrNull { it.proposerPublicKey == proposerPublicKey }

    private data class ReownAuthObject(val value: Wallet.Model.Cacao) : WalletConnectAuthObject

    private companion object {
        const val TAG = "WalletConnect"
    }
}

private fun Wallet.Model.Namespace.Session.toWalletConnectSessionNamespace(): WalletConnectSessionNamespace = WalletConnectSessionNamespace(
    chains = chains,
    methods = methods,
    events = events,
    accounts = accounts,
)

private fun WalletConnectSessionNamespace.toReownSessionNamespace(): Wallet.Model.Namespace.Session = Wallet.Model.Namespace.Session(
    chains = chains,
    accounts = accounts,
    methods = methods,
    events = events,
)

private fun Wallet.Model.Namespace.Proposal.toWalletConnectProposalNamespace(): WalletConnectProposalNamespace = WalletConnectProposalNamespace(chains = chains)

private fun Wallet.Model.SessionProposal.toWalletConnectSessionProposal(): WalletConnectSessionProposal = WalletConnectSessionProposal(
    name = name,
    description = description,
    url = url,
    icons = icons.map(URI::toString),
    requiredNamespaces = requiredNamespaces.mapValues { it.value.toWalletConnectProposalNamespace() },
    optionalNamespaces = optionalNamespaces.mapValues { it.value.toWalletConnectProposalNamespace() },
    proposerPublicKey = proposerPublicKey,
    pairingTopic = pairingTopic,
    properties = properties,
)

private fun Wallet.Model.SessionRequest.toWalletConnectSessionRequest(): WalletConnectSessionRequest = WalletConnectSessionRequest(
    topic = topic,
    chainId = chainId,
    request = WalletConnectJsonRpcRequest(
        id = request.id,
        method = request.method,
        params = request.params,
    ),
)

private fun Wallet.Model.PayloadAuthRequestParams.toWalletConnectAuthPayloadParams(): WalletConnectAuthPayloadParams = WalletConnectAuthPayloadParams(
    chains = chains,
    domain = domain,
    nonce = nonce,
    aud = aud,
    type = type,
    iat = iat,
    nbf = nbf,
    exp = exp,
    statement = statement,
    requestId = requestId,
    resources = resources,
    signatureTypes = signatureTypes,
)

private fun WalletConnectAuthPayloadParams.toReownPayloadAuthRequestParams(): Wallet.Model.PayloadAuthRequestParams = Wallet.Model.PayloadAuthRequestParams(
    chains = chains,
    domain = domain,
    nonce = nonce,
    aud = aud,
    type = type,
    iat = iat,
    nbf = nbf,
    exp = exp,
    statement = statement,
    requestId = requestId,
    resources = resources,
    signatureTypes = signatureTypes,
)

private fun Wallet.Model.VerifyContext.toWalletConnectVerifyContext(): WalletConnectVerifyContext = WalletConnectVerifyContext(
    origin = origin,
    validation = when (validation) {
        Wallet.Model.Validation.VALID -> WalletConnectValidation.Valid
        Wallet.Model.Validation.INVALID -> WalletConnectValidation.Invalid
        Wallet.Model.Validation.UNKNOWN -> WalletConnectValidation.Unknown
    },
    isScam = isScam,
)
