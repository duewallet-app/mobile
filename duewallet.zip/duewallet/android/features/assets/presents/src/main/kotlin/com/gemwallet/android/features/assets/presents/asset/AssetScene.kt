package com.gemwallet.android.features.assets.presents.asset

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import com.gemwallet.android.domains.confirm.ConfirmTransferInput
import com.gemwallet.android.ext.toAssetId
import com.gemwallet.android.ext.toPrimitives
import com.gemwallet.android.features.assets.presents.asset.components.AssetDetailRowItem
import com.gemwallet.android.features.assets.presents.asset.components.AssetDetailsMenu
import com.gemwallet.android.features.assets.presents.asset.components.AssetHeadItem
import com.gemwallet.android.features.assets.presents.asset.components.BannerItem
import com.gemwallet.android.features.assets.presents.asset.components.EmptyTransactionsItem
import com.gemwallet.android.features.assets.viewmodels.asset.models.AssetAction
import com.gemwallet.android.features.assets.viewmodels.asset.models.detailsAction
import com.gemwallet.android.features.assets.viewmodels.asset.models.navigation
import com.gemwallet.android.ui.R
import com.gemwallet.android.ui.components.list_item.GemListRowView
import com.gemwallet.android.ui.components.list_item.SubheaderItem
import com.gemwallet.android.ui.components.list_item.property.itemsPositioned
import com.gemwallet.android.ui.components.list_item.property.verificationStatusItem
import com.gemwallet.android.ui.components.list_item.rememberDateSections
import com.gemwallet.android.ui.components.list_item.transaction.transactionsList
import com.gemwallet.android.ui.components.screen.PullToRefreshBox
import com.gemwallet.android.ui.components.screen.Scene
import com.gemwallet.android.ui.components.screen.showSnackbar
import com.gemwallet.android.ui.localization.titleRes
import com.gemwallet.android.ui.models.ListPosition
import com.wallet.core.primitives.Asset
import com.wallet.core.primitives.TransactionId
import uniffi.gemstone.GemAssetDetails
import uniffi.gemstone.GemEmptyStateAction
import uniffi.gemstone.GemListPhase
import uniffi.gemstone.GemListRow
import uniffi.gemstone.GemTransactionRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AssetScene(
    details: GemAssetDetails,
    asset: Asset,
    transactions: List<GemTransactionRow>,
    transactionsPhase: GemListPhase?,
    isRefreshing: Boolean,
    snackBar: SnackbarHostState = remember { SnackbarHostState() },
    onAction: (AssetAction) -> Unit,
) {
    val detailsState = details.state
    val swapAction: () -> Unit = {
        details.swapPair.payAssetId.toAssetId()?.let { payAssetId ->
            onAction(AssetAction.Swap(fromAssetId = payAssetId, toAssetId = details.swapPair.receiveAssetId?.toAssetId()))
        }
    }

    Scene(
        titleContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = details.title,
                    maxLines = 1,
                    overflow = TextOverflow.MiddleEllipsis,
                )
            }
        },
        progress = null,
        actions = {
            AssetDetailsMenu(
                details = details,
                onPriceAlert = { onAction(AssetAction.TogglePriceAlert) },
            )
        },
        onClose = { onAction(AssetAction.Close) },
        snackbar = snackBar,
    ) {
        val transactionSections = rememberDateSections(transactions) { it.createdAt }
        val onTransactionClick: (TransactionId) -> Unit = { onAction(AssetAction.OpenTransaction(it)) }
        PullToRefreshBox(
            modifier = Modifier.fillMaxSize(),
            isRefreshing = isRefreshing,
            onRefresh = { onAction(AssetAction.Refresh) },
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
            ) {
                item {
                    AssetHeadItem(header = details.header, onAction = onAction)
                }
                val banner = details.banner
                if (detailsState.showsBanners && banner != null) {
                    item {
                        BannerItem(
                            banner = banner,
                            onStake = { onAction(AssetAction.Stake(asset.id)) },
                            onActivate = { onAction(AssetAction.Confirm(ConfirmTransferInput(it))) },
                            onOpenPerpetuals = { onAction(AssetAction.OpenPerpetuals) },
                            onClose = { onAction(AssetAction.CloseBanner(it)) },
                        )
                    }
                }
                details.verificationStatus?.let { verificationStatusItem(it.toPrimitives()) }
                val network = details.networkDestination.navigation()
                details.sections.forEach { section ->
                    section.title.titleRes()?.let { title -> item { SubheaderItem(title) } }
                    itemsPositioned(section.rows) { position, row ->
                        AssetDetailRowItem(row = row, action = row.detailsAction(asset.id, network), listPosition = position, onAction = onAction)
                    }
                }
                when (transactionsPhase) {
                    is GemListPhase.Error -> item {
                        GemListRowView(row = GemListRow.Error(transactionsPhase.error), listPosition = ListPosition.Single)
                    }

                    is GemListPhase.Empty -> item {
                        EmptyTransactionsItem(
                            symbol = asset.symbol,
                            state = transactionsPhase.state,
                            onAction = { action ->
                                when (action) {
                                    GemEmptyStateAction.BUY -> onAction(AssetAction.Buy(asset.id))
                                    GemEmptyStateAction.SWAP -> swapAction()
                                    GemEmptyStateAction.RECEIVE, GemEmptyStateAction.ADD_CUSTOM_TOKEN, GemEmptyStateAction.MANAGE_TOKEN_LIST, GemEmptyStateAction.CLEAR_FILTERS -> Unit
                                }
                            },
                        )
                    }

                    GemListPhase.Rows, null -> Unit
                }
                transactionsList(transactionSections, onTransactionClick)
            }
        }
    }
}
